#!/usr/bin/python3

#Para poder ejecutar este programa en Linux, debes darle permisos de ejecucion
#desde la interfaz o desde consola con chmod +x ./leerPDF.py
#También si tiene alguna dependencia, has de instalarla

#Importamos el modulo PyPDF2. Tenemos que haberlo instalado antes con
#la orden  pip3 install PyPDF2
import PyPDF2


#Ponemos en una variable la ruta del PDF a leer
#Imprimimos mensaje pidiendo PDF
print("Introduce la ruta del PDF a leer")
#leemos de teclado el PDF
pdfALeer=input()

#Abrimos el fichero del pdfALeer y guardamos su referencia en tmp
temp = open(pdfALeer, 'rb')

#Con la referencia del fichero abierto, cargamos el lector de PDFs
PDF_read = PyPDF2.PdfFileReader(temp)
#Ponemos la referencia del PDF a la primera pagina (pagina 0)
primeraPagina = PDF_read.getPage(0)
#Imprimimos por pantalla el texto extraido
print(primeraPagina.extractText())
# Cerramos el fichero del PDf
temp.close()
